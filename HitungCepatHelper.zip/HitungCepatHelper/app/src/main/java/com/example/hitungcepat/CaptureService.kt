package com.example.hitungcepat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {

    // ===== Area soal di layar (pecahan dari tinggi layar). Sesuaikan jika perlu =====
    private val CROP_TOP = 0.235f
    private val CROP_HEIGHT = 0.055f
    private val INTERVAL_MS = 500L   // cek tiap 0.5 detik

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private lateinit var wm: WindowManager
    private var overlay: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var busy = false
    private var sw = 0
    private var sh = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        startForegroundCompat()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels

        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "cap", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )

        createOverlay()
        handler.post(loop)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val ch = "cap"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Helper", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Hitung Helper aktif")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(1, n)
    }

    private fun createOverlay() {
        val tv = TextView(this).apply {
            text = "…"
            textSize = 34f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(200, 0, 0, 0))
            setPadding(40, 20, 40, 20)
            gravity = Gravity.CENTER
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sw / 3
            y = (sh * 0.80f).toInt()   // di area kosong bawah, di luar area soal
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var downT = 0L; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                    downT = System.currentTimeMillis(); moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    lp.x = ox + dx; lp.y = oy + dy
                    wm.updateViewLayout(tv, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && System.currentTimeMillis() - downT > 800) stopSelf() // tekan lama = tutup
                }
            }
            true
        }
        wm.addView(tv, lp)
        overlay = tv
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!busy) grabAndRead()
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    private fun grabAndRead() {
        val img = reader?.acquireLatestImage() ?: return
        val bmp: Bitmap
        try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * sw
            val full = Bitmap.createBitmap(sw + rowPadding / plane.pixelStride, sh, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val top = (sh * CROP_TOP).toInt()
            val hh = (sh * CROP_HEIGHT).toInt()
            bmp = Bitmap.createBitmap(full, 0, top, sw, hh)
            full.recycle()
        } finally {
            img.close()
        }
        val big = Bitmap.createScaledBitmap(bmp, bmp.width * 2, bmp.height * 2, true)
        bmp.recycle()
        busy = true
        recognizer.process(InputImage.fromBitmap(big, 0))
            .addOnSuccessListener { r ->
                val ans = solve(r.text) ?: solveByBoxes(r, big)
                overlay?.text = ans ?: ("? [" + r.text.replace("\n", " ").take(25) + "]")
            }
            .addOnCompleteListener { busy = false; big.recycle() }
    }

    private fun solve(raw: String): String? {
        val t = raw.replace("\n", " ").replace("−", "-").replace("—", "-")
        val m = Regex("(\\d+)\\s*([+\\-xX×*:÷/])\\s*(\\d+)").find(t) ?: return null
        val a = m.groupValues[1].toLong()
        val b = m.groupValues[3].toLong()
        return fmt(a, m.groupValues[2], b)
    }

    // Jika OCR tidak membaca simbol operator, baca 2 angka lalu deteksi operator dari piksel
    private fun solveByBoxes(r: Text, bmp: Bitmap): String? {
        val nums = r.textBlocks.flatMap { it.lines }.flatMap { it.elements }
            .filter { it.text.trim().matches(Regex("\\d+")) && it.boundingBox != null }
            .sortedBy { it.boundingBox!!.left }
        if (nums.size < 2) return null
        val n1 = nums[0]; val n2 = nums[1]
        val a = n1.text.trim().toLong(); val b = n2.text.trim().toLong()
        val x0 = n1.boundingBox!!.right + 8
        val x1 = n2.boundingBox!!.left - 8
        val y0 = minOf(n1.boundingBox!!.top, n2.boundingBox!!.top)
        val y1 = maxOf(n1.boundingBox!!.bottom, n2.boundingBox!!.bottom)
        val op = detectOp(bmp, x0, x1, y0, y1) ?: return null
        return fmt(a, op, b)
    }

    private fun detectOp(bmp: Bitmap, x0: Int, x1: Int, y0: Int, y1: Int): String? {
        val xa = x0.coerceIn(0, bmp.width - 1); val xb = x1.coerceIn(xa + 1, bmp.width)
        val ya = y0.coerceIn(0, bmp.height - 1); val yb = y1.coerceIn(ya + 1, bmp.height)
        var minX = Int.MAX_VALUE; var maxX = -1; var minY = Int.MAX_VALUE; var maxY = -1
        val dark = Array(yb - ya) { BooleanArray(xb - xa) }
        for (y in ya until yb) for (x in xa until xb) {
            val c = bmp.getPixel(x, y)
            val lum = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
            if (lum < 110) {
                dark[y - ya][x - xa] = true
                if (x < minX) minX = x; if (x > maxX) maxX = x
                if (y < minY) minY = y; if (y > maxY) maxY = y
            }
        }
        if (maxX < 0) return null
        val w = maxX - minX + 1; val h = maxY - minY + 1
        if (w > h * 1.8) return "-"
        if (h > w * 1.6) return ":"
        // bagian tengah: baris & kolom
        val cy = (minY + maxY) / 2 - ya; val cx = (minX + maxX) / 2 - xa
        val band = maxOf(1, minOf(w, h) / 8)
        fun rowFill(): Float {
            var n = 0; var t = 0
            for (y in cy - band..cy + band) for (x in minX - xa..maxX - xa) {
                if (y in dark.indices && x in dark[0].indices) { t++; if (dark[y][x]) n++ }
            }
            return if (t == 0) 0f else n.toFloat() / t
        }
        fun colFill(): Float {
            var n = 0; var t = 0
            for (x in cx - band..cx + band) for (y in minY - ya..maxY - ya) {
                if (y in dark.indices && x in dark[0].indices) { t++; if (dark[y][x]) n++ }
            }
            return if (t == 0) 0f else n.toFloat() / t
        }
        val rf = rowFill(); val cf = colFill()
        return when {
            rf > 0.8f && cf > 0.8f -> "+"
            rf > 0.8f && cf <= 0.8f -> "÷"
            else -> "×"
        }
    }

    private fun fmt(a: Long, op: String, b: Long): String? {
        val r = calc(a, op, b) ?: return null
        val o = if (op == "x" || op == "X" || op == "*") "×" else op
        return "$a $o $b\n= $r"
    }

    private fun calc(a: Long, op: String, b: Long): String? = when (op) {
        "+" -> (a + b).toString()
        "-" -> (a - b).toString()
        "x", "X", "×", "*" -> (a * b).toString()
        ":", "÷", "/" -> if (b == 0L) null else if (a % b == 0L) (a / b).toString()
                         else String.format("%.2f", a.toDouble() / b)
        else -> null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        overlay?.let { runCatching { wm.removeView(it) } }
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
