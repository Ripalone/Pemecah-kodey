package com.example.hitungcepat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {

    // ===== Area soal di layar (pecahan dari tinggi layar). Sesuaikan jika perlu =====
    private val CROP_TOP = 0.20f
    private val CROP_HEIGHT = 0.15f
    private val INTERVAL_MS = 500L   // cek tiap 0.5 detik

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private lateinit var wm: WindowManager
    private var overlay: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var busy = false
    private var sw = 0
    private var sh = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        startForegroundCompat()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels

        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "cap", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )

        createOverlay()
        handler.post(loop)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val ch = "cap"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Helper", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Hitung Helper aktif")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(1, n)
    }

    private fun createOverlay() {
        val tv = TextView(this).apply {
            text = "…"
            textSize = 44f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(200, 0, 0, 0))
            setPadding(40, 20, 40, 20)
            gravity = Gravity.CENTER
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sw / 3
            y = (sh * 0.62f).toInt()   // di area kosong bawah, di luar area soal
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var downT = 0L; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                    downT = System.currentTimeMillis(); moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    lp.x = ox + dx; lp.y = oy + dy
                    wm.updateViewLayout(tv, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && System.currentTimeMillis() - downT > 800) stopSelf() // tekan lama = tutup
                }
            }
            true
        }
        wm.addView(tv, lp)
        overlay = tv
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!busy) grabAndRead()
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    private fun grabAndRead() {
        val img = reader?.acquireLatestImage() ?: return
        val bmp: Bitmap
        try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * sw
            val full = Bitmap.createBitmap(sw + rowPadding / plane.pixelStride, sh, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val top = (sh * CROP_TOP).toInt()
            val hh = (sh * CROP_HEIGHT).toInt()
            bmp = Bitmap.createBitmap(full, 0, top, sw, hh)
            full.recycle()
        } finally {
            img.close()
        }
        busy = true
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                solve(r.text)?.let { overlay?.text = it }
            }
            .addOnCompleteListener { busy = false; bmp.recycle() }
    }

    private fun solve(raw: String): String? {
        val t = raw.replace("\n", " ").replace("−", "-").replace("—", "-")
        val m = Regex("(\\d+)\\s*([+\\-xX×*:÷/])\\s*(\\d+)").find(t) ?: return null
        val a = m.groupValues[1].toLong()
        val b = m.groupValues[3].toLong()
        return when (m.groupValues[2]) {
            "+" -> (a + b).toString()
            "-" -> (a - b).toString()
            "x", "X", "×", "*" -> (a * b).toString()
            ":", "÷", "/" -> if (b == 0L) null else if (a % b == 0L) (a / b).toString()
                             else String.format("%.2f", a.toDouble() / b)
            else -> null
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        overlay?.let { runCatching { wm.removeView(it) } }
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
